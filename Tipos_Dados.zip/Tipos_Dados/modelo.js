//Operador Ternário

const media = 7

const nota = 4


if (nota >= media) {

    console.log("Aluno Aprovado!!")

} else {
    console.log("Aluno Reprovado!")
}


//Operador Ternário

            //condição      //true             //false
console.log(nota >= media ? "Aluno Aprovado!": "Aluno Reprovado!")


/*------------------------------------------------------------------*/


//Template String

const nome = "Predo Henrique Sigma🗿🍷"

const cargo = "Sigma👨‍💼"

const empresa = "THE SIGMAS✌🤞"

const idade = 2023-2001

console.log("Me chamo "+nome+", sou "+cargo+", trabalho na empresa "+empresa+" e tenho "+idade+" anos de puro sigma🗿")


//Template String

console.log(`Me chamo ${nome}, sou ${cargo}, trabalho na empresa ${empresa} e tenho ${idade} anos de puro sigma🗿`)