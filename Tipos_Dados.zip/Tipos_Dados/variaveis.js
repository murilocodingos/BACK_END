//var

/*Funciona globalmente, ou seja, podemos declarar a variável em qualquer parte do código*/

exemplo2 = 15

console.log(exemplo2)

console.log(typeof exemplo2)

var exemplo2


/*-------------------------------*/


//let

exemplo3 = 30

console.log(exemplo3)

console.log(typeof exemplo2)

let exemplo3


/*-------------------------------*/


//const

/* As declarações const não podem ser restribuidas após a atribuição inicial e deve ser inicializada na mesma linha em que foi declarada */

const status = "Aluno Aprovado!"

const nota1 = 7
const nota2 = 4

let aprovacao

if (status === "Aluno Aprovado!") {

    aprovacao = nota1 + nota2
    console.log("Parabéns, Você foi Aprovado!")

}

