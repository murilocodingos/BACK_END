//Tipos de Dados


//Number
const numero1 = 10
const numero2 = 3

//Número de ponto flutuante
const numero3 = .5

const resultado = numero1 * numero2

console.log(resultado)

/* Not a Number (NaN): Quando um tipo de dado não é reconhecido na operação
const senai = "aula SESI"

const resultado = numero1 * senai

console.log(resultado) */


/*-------------------------------*/


//String

const texto1 = "Aula de Back-End"
const texto2 = ' no SESI Cajamar "Todas as Terças-Feiras"'

//Concatenação de Textos
console.log(texto1 + texto2)


/*-------------------------------*/


//Boolean

const nota1 = '9'
const nota2 = 9


//Quando queremos comparar se existe alguma igualdade seja no tipo ou valor
console.log(nota1 == nota2)

console.log(typeof nota2) 


/* Quando queremos comparar se o tipo e valor são totalmente iguais
console.log(nota1 === nota2)

console.log(typeof nota2) "Exibir o tipo da variável" */